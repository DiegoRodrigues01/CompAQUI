﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cadastro
{
    public class CadastroPessoa
    {
        private string connectionStr;
        public CadastroPessoa()
        {
            connectionStr = @"server=localhost;
                              port=3306;
                              uid=root;
                              pwd=1234;database=comparaqui;
                              ConnectionTimeout=1";
        }
        public void Pessoa(Login login)
        {
            MySqlConnection connectionBD = null;
            MySqlCommand cmdInsert = null;

            try
            {
                //tenta criar uma conexão com o banco
                connectionBD = new MySqlConnection(connectionStr);

                //abre a conexão com o banco
                connectionBD.Open();

                // Executa um comando INSERT para inserir um registro na tabela 'Funcionario'
                // Como o INSERT não retorna valores, devemos executar o comando 'ExecuteNonQuery'
                cmdInsert = new MySqlCommand();

                //atribui uma conexão ao comando (obrigatório)
                cmdInsert.Connection = connectionBD;

                //seta o comando sql que será executado
                cmdInsert.CommandText = "INSERT INTO Pessoa (nome, cpf, email, senha)" +
                                    "VALUES ( @nome, @cpf, @email, @senha)";

                //seta os parametros que deverão ser passados para a consulta sql
                cmdInsert.Parameters.AddWithValue("nome", login.getNome());
                cmdInsert.Parameters.AddWithValue("cpf", login.getCPF());
                cmdInsert.Parameters.AddWithValue("email", login.getEmail());
                cmdInsert.Parameters.AddWithValue("senha", login.getSenha());

                //executa o comando / consulta sql
                cmdInsert.ExecuteNonQuery();
            }
            finally
            {
                //libera a memória utilizada pelos comandos
                if (cmdInsert != null) cmdInsert.Dispose();
                //fecha a conexão com o banco!
                if (connectionBD != null) connectionBD.Close();
            }
   
        }
        public bool ValidarLogin(string email, string senha)
        {
            using (MySqlConnection connectionBD = new MySqlConnection(connectionStr))
            {
                connectionBD.Open();

                string query = "SELECT COUNT(*) FROM Pessoa WHERE email = @email AND senha = @senha";

                using (MySqlCommand cmd = new MySqlCommand(query, connectionBD))
                {
                    cmd.Parameters.AddWithValue("email", email);
                    cmd.Parameters.AddWithValue("senha", senha);

                    int count = Convert.ToInt32(cmd.ExecuteScalar());

                    return count > 0;
                }
            }
        }
    }
}