﻿namespace Cadastro
{
    partial class TelaLogin
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.MinhaConta = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnBuscar = new System.Windows.Forms.PictureBox();
            this.btnRaioBusca = new System.Windows.Forms.PictureBox();
            this.btnListaCompras = new System.Windows.Forms.PictureBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.logoComparAQUI = new System.Windows.Forms.PictureBox();
            this.lblListaCompras = new System.Windows.Forms.Label();
            this.lblRaioBusca = new System.Windows.Forms.Label();
            this.lblSenhaMinhaConta = new System.Windows.Forms.Label();
            this.lblEmailMinhaConta = new System.Windows.Forms.Label();
            this.btnEntrar = new System.Windows.Forms.Button();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.pnlCadastro = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MinhaConta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBuscar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRaioBusca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnListaCompras)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoComparAQUI)).BeginInit();
            this.pnlCadastro.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(145)))), ((int)(((byte)(240)))));
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1270, 40);
            this.panel1.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(145)))), ((int)(((byte)(240)))));
            this.panel4.Location = new System.Drawing.Point(-2, 156);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1270, 40);
            this.panel4.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(72)))), ((int)(((byte)(200)))));
            this.panel2.Controls.Add(this.MinhaConta);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.btnBuscar);
            this.panel2.Controls.Add(this.btnRaioBusca);
            this.panel2.Controls.Add(this.btnListaCompras);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.logoComparAQUI);
            this.panel2.Controls.Add(this.lblListaCompras);
            this.panel2.Controls.Add(this.lblRaioBusca);
            this.panel2.Location = new System.Drawing.Point(-2, 40);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1267, 116);
            this.panel2.TabIndex = 5;
            // 
            // MinhaConta
            // 
            this.MinhaConta.BackgroundImage = global::ComparAQUI.Properties.Resources.minha_conta;
            this.MinhaConta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.MinhaConta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MinhaConta.ErrorImage = null;
            this.MinhaConta.InitialImage = null;
            this.MinhaConta.Location = new System.Drawing.Point(1150, 35);
            this.MinhaConta.Name = "MinhaConta";
            this.MinhaConta.Size = new System.Drawing.Size(60, 40);
            this.MinhaConta.TabIndex = 14;
            this.MinhaConta.TabStop = false;
            //this.MinhaConta.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1141, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 18);
            this.label1.TabIndex = 13;
            this.label1.Text = "Minha conta";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::ComparAQUI.Properties.Resources.colaborar;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(1039, 35);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(60, 40);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            //this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(1037, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 18);
            this.label4.TabIndex = 10;
            this.label4.Text = "Colaborar";
            // 
            // btnBuscar
            // 
            this.btnBuscar.BackgroundImage = global::ComparAQUI.Properties.Resources.botao_buscar;
            this.btnBuscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnBuscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscar.ErrorImage = null;
            this.btnBuscar.InitialImage = null;
            this.btnBuscar.Location = new System.Drawing.Point(675, 32);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(85, 51);
            this.btnBuscar.TabIndex = 9;
            this.btnBuscar.TabStop = false;
            // 
            // btnRaioBusca
            // 
            this.btnRaioBusca.BackgroundImage = global::ComparAQUI.Properties.Resources.raio1;
            this.btnRaioBusca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnRaioBusca.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRaioBusca.ErrorImage = null;
            this.btnRaioBusca.InitialImage = null;
            this.btnRaioBusca.Location = new System.Drawing.Point(810, 35);
            this.btnRaioBusca.Name = "btnRaioBusca";
            this.btnRaioBusca.Size = new System.Drawing.Size(60, 40);
            this.btnRaioBusca.TabIndex = 8;
            this.btnRaioBusca.TabStop = false;
            this.btnRaioBusca.Click += new System.EventHandler(this.btnRaioBusca_Click);
            // 
            // btnListaCompras
            // 
            this.btnListaCompras.BackgroundImage = global::ComparAQUI.Properties.Resources.carrinho1;
            this.btnListaCompras.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnListaCompras.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnListaCompras.ErrorImage = null;
            this.btnListaCompras.InitialImage = null;
            this.btnListaCompras.Location = new System.Drawing.Point(927, 35);
            this.btnListaCompras.Name = "btnListaCompras";
            this.btnListaCompras.Size = new System.Drawing.Size(60, 40);
            this.btnListaCompras.TabIndex = 7;
            this.btnListaCompras.TabStop = false;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(216, 46);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(453, 29);
            this.textBox2.TabIndex = 12;
            // 
            // logoComparAQUI
            // 
            this.logoComparAQUI.BackgroundImage = global::ComparAQUI.Properties.Resources.logo_menor;
            this.logoComparAQUI.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.logoComparAQUI.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logoComparAQUI.ErrorImage = null;
            this.logoComparAQUI.InitialImage = null;
            this.logoComparAQUI.Location = new System.Drawing.Point(67, 6);
            this.logoComparAQUI.Name = "logoComparAQUI";
            this.logoComparAQUI.Size = new System.Drawing.Size(104, 103);
            this.logoComparAQUI.TabIndex = 0;
            this.logoComparAQUI.TabStop = false;
            // 
            // lblListaCompras
            // 
            this.lblListaCompras.AutoSize = true;
            this.lblListaCompras.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblListaCompras.ForeColor = System.Drawing.Color.White;
            this.lblListaCompras.Location = new System.Drawing.Point(904, 79);
            this.lblListaCompras.Name = "lblListaCompras";
            this.lblListaCompras.Size = new System.Drawing.Size(106, 18);
            this.lblListaCompras.TabIndex = 6;
            this.lblListaCompras.Text = "Lista de Compras";
            // 
            // lblRaioBusca
            // 
            this.lblRaioBusca.AutoSize = true;
            this.lblRaioBusca.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaioBusca.ForeColor = System.Drawing.Color.White;
            this.lblRaioBusca.Location = new System.Drawing.Point(796, 78);
            this.lblRaioBusca.Name = "lblRaioBusca";
            this.lblRaioBusca.Size = new System.Drawing.Size(88, 18);
            this.lblRaioBusca.TabIndex = 4;
            this.lblRaioBusca.Text = "Raio de Busca";
            // 
            // lblSenhaMinhaConta
            // 
            this.lblSenhaMinhaConta.AutoSize = true;
            this.lblSenhaMinhaConta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.lblSenhaMinhaConta.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSenhaMinhaConta.ForeColor = System.Drawing.Color.White;
            this.lblSenhaMinhaConta.Location = new System.Drawing.Point(24, 107);
            this.lblSenhaMinhaConta.Name = "lblSenhaMinhaConta";
            this.lblSenhaMinhaConta.Size = new System.Drawing.Size(61, 24);
            this.lblSenhaMinhaConta.TabIndex = 10;
            this.lblSenhaMinhaConta.Text = "Senha:";
            // 
            // lblEmailMinhaConta
            // 
            this.lblEmailMinhaConta.AutoSize = true;
            this.lblEmailMinhaConta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.lblEmailMinhaConta.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailMinhaConta.ForeColor = System.Drawing.Color.White;
            this.lblEmailMinhaConta.Location = new System.Drawing.Point(497, 271);
            this.lblEmailMinhaConta.Name = "lblEmailMinhaConta";
            this.lblEmailMinhaConta.Size = new System.Drawing.Size(67, 24);
            this.lblEmailMinhaConta.TabIndex = 15;
            this.lblEmailMinhaConta.Text = "E-mail: ";
            // 
            // btnEntrar
            // 
            this.btnEntrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.btnEntrar.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEntrar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.btnEntrar.Location = new System.Drawing.Point(27, 205);
            this.btnEntrar.Name = "btnEntrar";
            this.btnEntrar.Size = new System.Drawing.Size(265, 34);
            this.btnEntrar.TabIndex = 20;
            this.btnEntrar.Text = "Entrar";
            this.btnEntrar.UseVisualStyleBackColor = false;
            this.btnEntrar.Click += new System.EventHandler(this.btnEntrar_Click);
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(501, 298);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(265, 30);
            this.txtEmail.TabIndex = 25;
            // 
            // txtSenha
            // 
            this.txtSenha.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSenha.Location = new System.Drawing.Point(27, 135);
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.Size = new System.Drawing.Size(265, 30);
            this.txtSenha.TabIndex = 26;
            // 
            // pnlCadastro
            // 
            this.pnlCadastro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.pnlCadastro.Controls.Add(this.txtSenha);
            this.pnlCadastro.Controls.Add(this.lblSenhaMinhaConta);
            this.pnlCadastro.Controls.Add(this.btnEntrar);
            this.pnlCadastro.Location = new System.Drawing.Point(473, 240);
            this.pnlCadastro.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pnlCadastro.Name = "pnlCadastro";
            this.pnlCadastro.Size = new System.Drawing.Size(316, 275);
            this.pnlCadastro.TabIndex = 32;
            // 
            // TelaLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.ClientSize = new System.Drawing.Size(1203, 671);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblEmailMinhaConta);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlCadastro);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1280, 717);
            this.MinimumSize = new System.Drawing.Size(1082, 698);
            this.Name = "TelaLogin";
            this.Text = "ComparAQUI";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MinhaConta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBuscar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRaioBusca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnListaCompras)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoComparAQUI)).EndInit();
            this.pnlCadastro.ResumeLayout(false);
            this.pnlCadastro.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblRaioBusca;
        private System.Windows.Forms.Label lblListaCompras;
        private System.Windows.Forms.PictureBox logoComparAQUI;
        private System.Windows.Forms.PictureBox btnListaCompras;
        private System.Windows.Forms.PictureBox btnRaioBusca;
        private System.Windows.Forms.PictureBox btnBuscar;
        private System.Windows.Forms.Label lblSenhaMinhaConta;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblEmailMinhaConta;
        private System.Windows.Forms.Button btnEntrar;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.PictureBox MinhaConta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.Panel pnlCadastro;
    }
}

