﻿using Cadastro;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComparAQUI
{
    public partial class TelaInicial : Form
    {
        private bool isPanelVisible = false;

        private MySqlConnection connection;
        public TelaInicial()
        {
            InitializeComponent(); 
        }
        //arredondando botões
        protected override void OnPaint(PaintEventArgs e)
        {
            GraphicsPath forma1 = new GraphicsPath();
            forma1.AddEllipse(0, 0, button2.Width, button2.Height);
            button2.Region = new Region(forma1);

            GraphicsPath forma2 = new GraphicsPath();
            forma2.AddEllipse(0, 0, button3.Width, button3.Height);
            button3.Region = new Region(forma2);

            GraphicsPath forma3 = new GraphicsPath();
            forma3.AddEllipse(0, 0, button4.Width, button4.Height);
            button4.Region = new Region(forma3);

            GraphicsPath forma4 = new GraphicsPath();
            forma4.AddEllipse(0, 0, button5.Width, button5.Height);
            button5.Region = new Region(forma4);

            GraphicsPath forma5 = new GraphicsPath();
            forma5.AddEllipse(0, 0, button6.Width, button6.Height);
            button6.Region = new Region(forma5);

            GraphicsPath forma6 = new GraphicsPath();
            forma6.AddEllipse(0,0, button7.Width, button7.Height);
            button7.Region = new Region(forma6);

            GraphicsPath forma7 = new GraphicsPath();
            forma7.AddEllipse(0, 0, button8.Width, button8.Height);
            button8.Region = new Region(forma6);

            GraphicsPath forma8 = new GraphicsPath();
            forma8.AddEllipse(0, 0, button9.Width, button9.Height);
            button9.Region = new Region(forma6);
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            CadastroPessoa cadastroPessoa = new CadastroPessoa();

            TelaCadastro cadastro= new TelaCadastro( cadastroPessoa);
            cadastro.Show();
        }

        private void btnColaborar_Click(object sender, EventArgs e)
        {
            this.Close();
            CadastroPessoa cadastroPessoa = new CadastroPessoa();

            TelaLogin login = new TelaLogin(cadastroPessoa);
            login.Show();
        }
        private void btnRaioBusca_Click(object sender, EventArgs e)
        {
            this.Close();
            TelaRaio telaRaio = new TelaRaio();
            telaRaio.Show();
        }
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                string nome = txtBuscar.Text.Trim();
                if (nome == "")
                {
                    return;
                }
                string connectionString = @"server=localhost;
                              port=3306;
                              uid=root;
                              pwd=1234;database=comparaqui;
                              ConnectionTimeout=1";

                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query = $"SELECT nome, preco, imagem FROM produtos_brasil WHERE nome LIKE '%{nome}%'";


                    MySqlCommand command = new MySqlCommand(query, connection);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (MySqlException erro)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine(erro.GetType().ToString());
                sb.AppendLine(erro.Message);
                sb.Append(erro.SqlState);
                sb.AppendLine("\n");
                sb.AppendLine(erro.StackTrace);
                MessageBox.Show(sb.ToString(), "ERRO BANCO!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception erro)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine(erro.GetType().ToString());
                sb.AppendLine(erro.Message);
                sb.AppendLine("\n");
                sb.AppendLine(erro.StackTrace);
                MessageBox.Show(sb.ToString(), "ERRO Desconhecido!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
    

