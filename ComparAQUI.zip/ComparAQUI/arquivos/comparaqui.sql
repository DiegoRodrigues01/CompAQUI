CREATE DATABASE comparaqui;

USE comparaqui;

CREATE TABLE pessoa (
	id INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(14) NOT NULL,
    email VARCHAR(100) NOT NULL,
    senha VARCHAR(100) NOT NULL,
    PRIMARY KEY (id)
);
SELECT COUNT(*) AS quantidade_pessoas FROM pessoa;

CREATE TABLE categoria (
	id INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    PRIMARY KEY (id)
); 

CREATE TABLE produtos_brasil (
	id INT NOT NULL AUTO_INCREMENT,
    id_categoria INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    imagem VARCHAR(100) NOT NULL,
    preco VARCHAR (20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_categoria) REFERENCES categoria (id)
); 

SELECT SUM(preco) AS valor_total FROM produtos_brasil;

CREATE TABLE produtos_dia (
	id INT NOT NULL AUTO_INCREMENT,
    id_categoria INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    imagem VARCHAR(100) NOT NULL,
    preco VARCHAR (20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_categoria) REFERENCES categoria (id)
); 
SELECT SUM(preco) AS valor_total FROM produtos_dia;
    
CREATE TABLE produtos_paguemenos (
	id INT NOT NULL AUTO_INCREMENT,
    id_categoria INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    imagem VARCHAR(100) NOT NULL,
    preco VARCHAR (20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_categoria) REFERENCES categoria (id)
); 
SELECT SUM(preco) AS valor_total FROM produtos_paguemenos;

CREATE TABLE produtos_oliveira (
	id INT NOT NULL AUTO_INCREMENT,
    id_categoria INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    imagem VARCHAR(100) NOT NULL,
    preco VARCHAR (20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_categoria) REFERENCES categoria (id)
); 
SELECT SUM(preco) AS valor_total FROM produtos_oliveira;

CREATE TABLE produtos_sonda (
	id INT NOT NULL AUTO_INCREMENT,
    id_categoria INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    imagem VARCHAR(100) NOT NULL,
    preco VARCHAR (20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_categoria) REFERENCES categoria (id)
); 
SELECT SUM(preco) AS valor_total FROM produtos_sonda;

CREATE TABLE produtos_topazio (
	id INT NOT NULL AUTO_INCREMENT,
    id_categoria INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    imagem VARCHAR(100) NOT NULL,
    preco VARCHAR (20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_categoria) REFERENCES categoria (id)
); 
SELECT SUM(preco) AS valor_topazio FROM produtos_paguemenos;

CREATE TABLE produtos_atacadao (
	id INT NOT NULL AUTO_INCREMENT,
    id_categoria INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    imagem VARCHAR(100) NOT NULL,
    preco VARCHAR (20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_categoria) REFERENCES categoria (id)
); 
SELECT SUM(preco) AS valor_atacadao FROM produtos_paguemenos;

CREATE TABLE produtos_caetano (
	id INT NOT NULL AUTO_INCREMENT,
    id_categoria INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    imagem VARCHAR(100) NOT NULL,
    preco VARCHAR (20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_categoria) REFERENCES categoria (id)
); 
SELECT SUM(preco) AS valor_total FROM produtos_caetano;

CREATE TABLE produtos_enxuto (
	id INT NOT NULL AUTO_INCREMENT,
    id_categoria INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    imagem VARCHAR(100) NOT NULL,
    preco VARCHAR (20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_categoria) REFERENCES categoria (id)
); 
SELECT SUM(preco) AS valor_total FROM produtos_enxuto;

CREATE TABLE historico_lista (
	id INT NOT NULL AUTO_INCREMENT,
    pessoa_id INT NOT NULL,
    PRIMARY KEY (id), 
    FOREIGN KEY (pessoa_id) REFERENCES pessoa (id)
);

INSERT INTO categoria (nome) VALUES
	('Arroz'),
	('Feijão'),
	('Macarrão'),
	('Leite'),
	('Biscoito Doce'),
	('Biscoito Salgado'),
	('Açucar'),
	('Café');

INSERT INTO produtos_brasil (nome, id_categoria, imagem, preco) VALUES
	('Arroz Branco Longo-fino Tipo 1 Camil Todo Dia 1Kg', '1', 'arroz.jpg', '26.49'),
	('Arroz Branco Longo-fino Tipo 1 Tio João 5 Kg', '1', 'arroz.jpg', '29.99'),
	('Arroz Branco Longo-fino Tipo 1 Prato Fino 5 Kg', '1', 'arroz.jpg', '29.99'),
	('Feijão Carioca Broto Legal 1kg', '2', 'feijao.jpg', '8,99'),
	('Feijão Carioca Tipo 1 Kicaldo 1Kg', '2', 'feijao.jpg', '9,19'),
	('Feijão Carioca Tipo 1 Solito 1Kg', '2', 'feijao.jpg', '8,79'),
	('Macarrão de Sêmola com Ovos Espaguete 8 Adria 500g', '3', 'massa.jpg', '4,59'),
	('Macarrão de Sêmola com Ovos Parafuso Adria 500g', '3', 'massa.jpg', '4,59'),
	('Macarrão Espaguete Renata com Ovos Nº 8 500g', '3', 'massa.jpg', '5,59'),
	('Leite Integral UHT Italac 1 Litro', '4', 'leite.jpg', '4.99'),
	('Leite Integral UHT Mococa 1 Litro', '4', 'leite.jpg', '5.04'),
	('Leite Integral UHT Ninho Forti+ Vitaminado 1 L', '4', 'leite.jpg', '5.89'),
	('Biscoito Passatempo Recheado Chocolate 130 g', '5', 'bolacha.jpg', '2.99'),
	('Biscoito Recheado Trakinas Chocolate 126g', '5', 'bolacha.jpg', '4.09'),
	('Biscoito Chocolate Calipso 130 g', '5', 'bolacha.jpg', '10.69'),
	('Biscoito Salgado Club Social Original Embalagem Econômica 288g', '6', 'biscoito.jpg', '9,29'),
	('Biscoito Cream Cracker Amanteigado Vitarella 350g', '6', 'biscoito.jpg', '5.99'),
	('Biscoito Triunfo Cream Cracker 345g', '6', 'biscoito.jpg', '4.99'),
	('Açúcar Refinado Da Barra 1Kg', '7', 'acucar.jpg', '4.39'),
	('Açúcar Cristal Caravelas 1kg', '7', 'acucar.jpg', '3.78'),
	('Açúcar Cristal Pateko 1 Kg', '7', 'acucar.jpg', '3.89'),
	('Café A Vácuo Do Centro 500g', '8', 'cafe.jpg', '14.99'),
	('Café em Pó União 500g', '8', 'cafe.jpg', '19.59'),
	('Café Almofada Tradicional 3 Corações 500g', '8', 'cafe.jpg', '18.99');

INSERT INTO produtos_dia (nome, id_categoria, imagem, preco) VALUES
	('Arroz Branco Longo-fino Tipo 1 Camil Todo Dia 1Kg', '1', 'arroz.jpg', '30.99'),
	('Arroz Branco Longo-fino Tipo 1 Tio João 5 Kg', '1', 'arroz.jpg', '32.99'),
	('Arroz Branco Longo-fino Tipo 1 Prato Fino 5 Kg', '1', 'arroz.jpg', '32.99'),
	('Feijão Carioca Broto Legal 1kg', '2', 'feijao.jpg', '9.99'),
	('Feijão Carioca Tipo 1 Kicaldo 1Kg', '2', 'feijao.jpg', '10.49'),
	('Feijão Carioca Tipo 1 Solito 1Kg', '2', 'feijao.jpg', '9.79'),
	('Macarrão de Sêmola com Ovos Espaguete 8 Adria 500g', '3', 'massa.jpg', '5.59'),
	('Macarrão de Sêmola com Ovos Parafuso Adria 500g', '3', 'massa.jpg', '5.59'),
	('Macarrão Espaguete Renata com Ovos Nº 8 500g', '3', 'massa.jpg', '6.59'),
	('Leite Integral UHT Italac 1 Litro', '4', 'leite.jpg', '5.99'),
	('Leite Integral UHT Mococa 1 Litro', '4', 'leite.jpg', '6.04'),
	('Leite Integral UHT Ninho Forti+ Vitaminado 1 L', '4', 'leite.jpg', '6.89'),
	('Biscoito Passatempo Recheado Chocolate 130 g', '5', 'bolacha.jpg', '3.99'),
	('Biscoito Recheado Trakinas Chocolate 126g', '5', 'bolacha.jpg', '4.49'),
	('Biscoito Chocolate Calipso 130 g', '5', 'bolacha.jpg', '11.69'),
	('Biscoito Salgado Club Social Original Embalagem Econômica 288g', '6', 'biscoito.jpg', '9.99'),
	('Biscoito Cream Cracker Amanteigado Vitarella 350g', '6', 'biscoito.jpg', '6.99'),
	('Biscoito Triunfo Cream Cracker 345g', '6', 'biscoito.jpg', '5.49'),
	('Açúcar Refinado Da Barra 1Kg', '7', 'acucar.jpg', '4.99'),
	('Açúcar Cristal Caravelas 1kg', '7', 'acucar.jpg', '4.78'),
	('Açúcar Cristal Pateko 1 Kg', '7', 'acucar.jpg', '4.89'),
	('Café A Vácuo Do Centro 500g', '8', 'cafe.jpg', '15.99'),
	('Café em Pó União 500g', '8', 'cafe.jpg', '20.59'),
	('Café Almofada Tradicional 3 Corações 500g', '8', 'cafe.jpg', '19.99');
    
    INSERT INTO produtos_paguemenos (nome, id_categoria, imagem, preco) VALUES
	('Arroz Branco Longo-fino Tipo 1 Camil Todo Dia 1Kg', '1', 'arroz.jpg', '30.99'),
	('Arroz Branco Longo-fino Tipo 1 Tio João 5 Kg', '1', 'arroz.jpg', '32.99'),
	('Arroz Branco Longo-fino Tipo 1 Prato Fino 5 Kg', '1', 'arroz.jpg', '32.99'),
	('Feijão Carioca Broto Legal 1kg', '2', 'feijao.jpg', '9.99'),
	('Feijão Carioca Tipo 1 Kicaldo 1Kg', '2', 'feijao.jpg', '10.49'),
	('Feijão Carioca Tipo 1 Solito 1Kg', '2', 'feijao.jpg', '9.79'),
	('Macarrão de Sêmola com Ovos Espaguete 8 Adria 500g', '3', 'massa.jpg', '5.59'),
	('Macarrão de Sêmola com Ovos Parafuso Adria 500g', '3', 'massa.jpg', '5.59'),
	('Macarrão Espaguete Renata com Ovos Nº 8 500g', '3', 'massa.jpg', '6.59'),
	('Leite Integral UHT Italac 1 Litro', '4', 'leite.jpg', '5.99'),
	('Leite Integral UHT Mococa 1 Litro', '4', 'leite.jpg', '6.04'),
	('Leite Integral UHT Ninho Forti+ Vitaminado 1 L', '4', 'leite.jpg', '6.89'),
	('Biscoito Passatempo Recheado Chocolate 130 g', '5', 'bolacha.jpg', '3.99'),
	('Biscoito Recheado Trakinas Chocolate 126g', '5', 'bolacha.jpg', '4.49'),
	('Biscoito Chocolate Calipso 130 g', '5', 'bolacha.jpg', '11.69'),
	('Biscoito Salgado Club Social Original Embalagem Econômica 288g', '6', 'biscoito.jpg', '9.99'),
	('Biscoito Cream Cracker Amanteigado Vitarella 350g', '6', 'biscoito.jpg', '6.99'),
	('Biscoito Triunfo Cream Cracker 345g', '6', 'biscoito.jpg', '5.49'),
	('Açúcar Refinado Da Barra 1Kg', '7', 'acucar.jpg', '4.99'),
	('Açúcar Cristal Caravelas 1kg', '7', 'acucar.jpg', '4.78'),
	('Açúcar Cristal Pateko 1 Kg', '7', 'acucar.jpg', '4.89'),
	('Café A Vácuo Do Centro 500g', '8', 'cafe.jpg', '15.99'),
	('Café em Pó União 500g', '8', 'cafe.jpg', '20.59'),
	('Café Almofada Tradicional 3 Corações 500g', '8', 'cafe.jpg', '19.99');

INSERT INTO produtos_oliveira (nome, id_categoria, imagem, preco) VALUES
	('Arroz Branco Longo-fino Tipo 1 Camil Todo Dia 1Kg', '1', 'arroz.jpg', '26.49'),
	('Arroz Branco Longo-fino Tipo 1 Tio João 5 Kg', '1', 'arroz.jpg', '29.99'),
	('Arroz Branco Longo-fino Tipo 1 Prato Fino 5 Kg', '1', 'arroz.jpg', '29.99'),
	('Feijão Carioca Broto Legal 1kg', '2', 'feijao.jpg', '8,99'),
	('Feijão Carioca Tipo 1 Kicaldo 1Kg', '2', 'feijao.jpg', '9,19'),
	('Feijão Carioca Tipo 1 Solito 1Kg', '2', 'feijao.jpg', '8,79'),
	('Macarrão de Sêmola com Ovos Espaguete 8 Adria 500g', '3', 'massa.jpg', '4,59'),
	('Macarrão de Sêmola com Ovos Parafuso Adria 500g', '3', 'massa.jpg', '4,59'),
	('Macarrão Espaguete Renata com Ovos Nº 8 500g', '3', 'massa.jpg', '5,59'),
	('Leite Integral UHT Italac 1 Litro', '4', 'leite.jpg', '4.99'),
	('Leite Integral UHT Mococa 1 Litro', '4', 'leite.jpg', '5.04'),
	('Leite Integral UHT Ninho Forti+ Vitaminado 1 L', '4', 'leite.jpg', '5.89'),
	('Biscoito Passatempo Recheado Chocolate 130 g', '5', 'bolacha.jpg', '2.99'),
	('Biscoito Recheado Trakinas Chocolate 126g', '5', 'bolacha.jpg', '4.09'),
	('Biscoito Chocolate Calipso 130 g', '5', 'bolacha.jpg', '10.69'),
	('Biscoito Salgado Club Social Original Embalagem Econômica 288g', '6', 'biscoito.jpg', '9,29'),
	('Biscoito Cream Cracker Amanteigado Vitarella 350g', '6', 'biscoito.jpg', '5.99'),
	('Biscoito Triunfo Cream Cracker 345g', '6', 'biscoito.jpg', '4.99'),
	('Açúcar Refinado Da Barra 1Kg', '7', 'acucar.jpg', '4.39'),
	('Açúcar Cristal Caravelas 1kg', '7', 'acucar.jpg', '3.78'),
	('Açúcar Cristal Pateko 1 Kg', '7', 'acucar.jpg', '3.89'),
	('Café A Vácuo Do Centro 500g', '8', 'cafe.jpg', '14.99'),
	('Café em Pó União 500g', '8', 'cafe.jpg', '19.59'),
	('Café Almofada Tradicional 3 Corações 500g', '8', 'cafe.jpg', '18.99');

INSERT INTO produtos_sonda (nome, id_categoria, imagem, preco) VALUES
	('Arroz Branco Longo-fino Tipo 1 Camil Todo Dia 1Kg', '1', 'arroz.jpg', '26.49'),
	('Arroz Branco Longo-fino Tipo 1 Tio João 5 Kg', '1', 'arroz.jpg', '31.99'),
	('Arroz Branco Longo-fino Tipo 1 Prato Fino 5 Kg', '1', 'arroz.jpg', '28.99'),
	('Feijão Carioca Broto Legal 1kg', '2', 'feijao.jpg', '8.99'),
	('Feijão Carioca Tipo 1 Kicaldo 1Kg', '2', 'feijao.jpg', '9.79'),
	('Feijão Carioca Tipo 1 Solito 1Kg', '2', 'feijao.jpg', '8.59'),
	('Macarrão de Sêmola com Ovos Espaguete 8 Adria 500g', '3', 'massa.jpg', '4.59'),
	('Macarrão de Sêmola com Ovos Parafuso Adria 500g', '3', 'massa.jpg', '4.99'),
	('Macarrão Espaguete Renata com Ovos Nº 8 500g', '3', 'massa.jpg', '5.79'),
	('Leite Integral UHT Italac 1 Litro', '4', 'leite.jpg', '5.49'),
	('Leite Integral UHT Mococa 1 Litro', '4', 'leite.jpg', '5.19'),
	('Leite Integral UHT Ninho Forti+ Vitaminado 1 L', '4', 'leite.jpg', '6.49'),
	('Biscoito Passatempo Recheado Chocolate 130 g', '5', 'bolacha.jpg', '3.49'),
	('Biscoito Recheado Trakinas Chocolate 126g', '5', 'bolacha.jpg', '4.59'),
	('Biscoito Chocolate Calipso 130 g', '5', 'bolacha.jpg', '11.99'),
	('Biscoito Salgado Club Social Original Embalagem Econômica 288g', '6', 'biscoito.jpg', '8.99'),
	('Biscoito Cream Cracker Amanteigado Vitarella 350g', '6', 'biscoito.jpg', '6.49'),
	('Biscoito Triunfo Cream Cracker 345g', '6', 'biscoito.jpg', '5.49'),
	('Açúcar Refinado Da Barra 1Kg', '7', 'acucar.jpg', '4.79'),
	('Açúcar Cristal Caravelas 1kg', '7', 'acucar.jpg', '3.99'),
	('Açúcar Cristal Pateko 1 Kg', '7', 'acucar.jpg', '4.09'),
	('Café A Vácuo Do Centro 500g', '8', 'cafe.jpg', '15.99'),
	('Café em Pó União 500g', '8', 'cafe.jpg', '20.99'),
	('Café Almofada Tradicional 3 Corações 500g', '8', 'cafe.jpg', '18.49');

INSERT INTO produtos_topazio (nome, id_categoria, imagem, preco) VALUES
	('Arroz Branco Longo-fino Tipo 1 Camil Todo Dia 1Kg', '1', 'arroz.jpg', '25.99'),
	('Arroz Branco Longo-fino Tipo 1 Tio João 5 Kg', '1', 'arroz.jpg', '30.49'),
	('Arroz Branco Longo-fino Tipo 1 Prato Fino 5 Kg', '1', 'arroz.jpg', '28.79'),
	('Feijão Carioca Broto Legal 1kg', '2', 'feijao.jpg', '8.49'),
	('Feijão Carioca Tipo 1 Kicaldo 1Kg', '2', 'feijao.jpg', '9.69'),
	('Feijão Carioca Tipo 1 Solito 1Kg', '2', 'feijao.jpg', '8.39'),
	('Macarrão de Sêmola com Ovos Espaguete 8 Adria 500g', '3', 'massa.jpg', '4.29'),
	('Macarrão de Sêmola com Ovos Parafuso Adria 500g', '3', 'massa.jpg', '4.49'),
	('Macarrão Espaguete Renata com Ovos Nº 8 500g', '3', 'massa.jpg', '5.29'),
	('Leite Integral UHT Italac 1 Litro', '4', 'leite.jpg', '4.79'),
	('Leite Integral UHT Mococa 1 Litro', '4', 'leite.jpg', '4.84'),
	('Leite Integral UHT Ninho Forti+ Vitaminado 1 L', '4', 'leite.jpg', '5.69'),
	('Biscoito Passatempo Recheado Chocolate 130 g', '5', 'bolacha.jpg', '2.89'),
	('Biscoito Recheado Trakinas Chocolate 126g', '5', 'bolacha.jpg', '4.39'),
	('Biscoito Chocolate Calipso 130 g', '5', 'bolacha.jpg', '10.29'),
	('Biscoito Salgado Club Social Original Embalagem Econômica 288g', '6', 'biscoito.jpg', '8.09'),
	('Biscoito Cream Cracker Amanteigado Vitarella 350g', '6', 'biscoito.jpg', '5.49'),
	('Biscoito Triunfo Cream Cracker 345g', '6', 'biscoito.jpg', '4.59'),
	('Açúcar Refinado Da Barra 1Kg', '7', 'acucar.jpg', '4.19'),
	('Açúcar Cristal Caravelas 1kg', '7', 'acucar.jpg', '3.58'),
	('Açúcar Cristal Pateko 1 Kg', '7', 'acucar.jpg', '3.69'),
	('Café A Vácuo Do Centro 500g', '8', 'cafe.jpg', '14.49'),
	('Café em Pó União 500g', '8', 'cafe.jpg', '19.09'),
	('Café Almofada Tradicional 3 Corações 500g', '8', 'cafe.jpg', '18.49');

INSERT INTO produtos_atacadao (nome, id_categoria, imagem, preco) VALUES
	('Arroz Branco Longo-fino Tipo 1 Camil Todo Dia 1Kg', '1', 'arroz.jpg', '27.99'),
	('Arroz Branco Longo-fino Tipo 1 Tio João 5 Kg', '1', 'arroz.jpg', '31.29'),
	('Arroz Branco Longo-fino Tipo 1 Prato Fino 5 Kg', '1', 'arroz.jpg', '29.49'),
	('Feijão Carioca Broto Legal 1kg', '2', 'feijao.jpg', '8.69'),
	('Feijão Carioca Tipo 1 Kicaldo 1Kg', '2', 'feijao.jpg', '9.39'),
	('Feijão Carioca Tipo 1 Solito 1Kg', '2', 'feijao.jpg', '8.89'),
	('Macarrão de Sêmola com Ovos Espaguete 8 Adria 500g', '3', 'massa.jpg', '4.99'),
	('Macarrão de Sêmola com Ovos Parafuso Adria 500g', '3', 'massa.jpg', '5.19'),
	('Macarrão Espaguete Renata com Ovos Nº 8 500g', '3', 'massa.jpg', '5.99'),
	('Leite Integral UHT Italac 1 Litro', '4', 'leite.jpg', '5.29'),
	('Leite Integral UHT Mococa 1 Litro', '4', 'leite.jpg', '5.14'),
	('Leite Integral UHT Ninho Forti+ Vitaminado 1 L', '4', 'leite.jpg', '5.99'),
	('Biscoito Passatempo Recheado Chocolate 130 g', '5', 'bolacha.jpg', '3.19'),
	('Biscoito Recheado Trakinas Chocolate 126g', '5', 'bolacha.jpg', '4.49'),
	('Biscoito Chocolate Calipso 130 g', '5', 'bolacha.jpg', '10.99'),
	('Biscoito Salgado Club Social Original Embalagem Econômica 288g', '6', 'biscoito.jpg', '8.79'),
	('Biscoito Cream Cracker Amanteigado Vitarella 350g', '6', 'biscoito.jpg', '5.79'),
	('Biscoito Triunfo Cream Cracker 345g', '6', 'biscoito.jpg', '4.89'),
	('Açúcar Refinado Da Barra 1Kg', '7', 'acucar.jpg', '4.59'),
	('Açúcar Cristal Caravelas 1kg', '7', 'acucar.jpg', '3.98'),
	('Açúcar Cristal Pateko 1 Kg', '7', 'acucar.jpg', '4.09'),
	('Café A Vácuo Do Centro 500g', '8', 'cafe.jpg', '15.49'),
	('Café em Pó União 500g', '8', 'cafe.jpg', '19.99'),
	('Café Almofada Tradicional 3 Corações 500g', '8', 'cafe.jpg', '18.79');

INSERT INTO produtos_caetano (nome, id_categoria, imagem, preco) VALUES
	('Arroz Branco Longo-fino Tipo 1 Camil Todo Dia 1Kg', '1', 'arroz.jpg', '27.99'),
	('Arroz Branco Longo-fino Tipo 1 Tio João 5 Kg', '1', 'arroz.jpg', '30.49'),
	('Arroz Branco Longo-fino Tipo 1 Prato Fino 5 Kg', '1', 'arroz.jpg', '30.99'),
	('Feijão Carioca Broto Legal 1kg', '2', 'feijao.jpg', '8.79'),
	('Feijão Carioca Tipo 1 Kicaldo 1Kg', '2', 'feijao.jpg', '9.09'),
	('Feijão Carioca Tipo 1 Solito 1Kg', '2', 'feijao.jpg', '8.69'),
	('Macarrão de Sêmola com Ovos Espaguete 8 Adria 500g', '3', 'massa.jpg', '4.79'),
	('Macarrão de Sêmola com Ovos Parafuso Adria 500g', '3', 'massa.jpg', '4.79'),
	('Macarrão Espaguete Renata com Ovos Nº 8 500g', '3', 'massa.jpg', '5.69'),
	('Leite Integral UHT Italac 1 Litro', '4', 'leite.jpg', '5.09'),
	('Leite Integral UHT Mococa 1 Litro', '4', 'leite.jpg', '5.14'),
	('Leite Integral UHT Ninho Forti+ Vitaminado 1 L', '4', 'leite.jpg', '5.99'),
	('Biscoito Passatempo Recheado Chocolate 130 g', '5', 'bolacha.jpg', '2.79'),
	('Biscoito Recheado Trakinas Chocolate 126g', '5', 'bolacha.jpg', '3.99'),
	('Biscoito Chocolate Calipso 130 g', '5', 'bolacha.jpg', '10.29'),
	('Biscoito Salgado Club Social Original Embalagem Econômica 288g', '6', 'biscoito.jpg', '9,49'),
	('Biscoito Cream Cracker Amanteigado Vitarella 350g', '6', 'biscoito.jpg', '5.79'),
	('Biscoito Triunfo Cream Cracker 345g', '6', 'biscoito.jpg', '4.89'),
	('Açúcar Refinado Da Barra 1Kg', '7', 'acucar.jpg', '4.49'),
	('Açúcar Cristal Caravelas 1kg', '7', 'acucar.jpg', '3.88'),
	('Açúcar Cristal Pateko 1 Kg', '7', 'acucar.jpg', '3.99'),
	('Café A Vácuo Do Centro 500g', '8', 'cafe.jpg', '14.49'),
	('Café em Pó União 500g', '8', 'cafe.jpg', '19.19'),
	('Café Almofada Tradicional 3 Corações 500g', '8', 'cafe.jpg', '18.49');

INSERT INTO produtos_enxuto (nome, id_categoria, imagem, preco) VALUES
	('Arroz Branco Longo-fino Tipo 1 Camil Todo Dia 1Kg', '1', 'arroz.jpg', '28.99'),
	('Arroz Branco Longo-fino Tipo 1 Tio João 5 Kg', '1', 'arroz.jpg', '30.99'),
	('Arroz Branco Longo-fino Tipo 1 Prato Fino 5 Kg', '1', 'arroz.jpg', '30.99'),
	('Feijão Carioca Broto Legal 1kg', '2', 'feijao.jpg', '8.49'),
	('Feijão Carioca Tipo 1 Kicaldo 1Kg', '2', 'feijao.jpg', '9.29'),
	('Feijão Carioca Tipo 1 Solito 1Kg', '2', 'feijao.jpg', '8.89'),
	('Macarrão de Sêmola com Ovos Espaguete 8 Adria 500g', '3', 'massa.jpg', '4.39'),
	('Macarrão de Sêmola com Ovos Parafuso Adria 500g', '3', 'massa.jpg', '4.39'),
	('Macarrão Espaguete Renata com Ovos Nº 8 500g', '3', 'massa.jpg', '5.79'),
	('Leite Integral UHT Italac 1 Litro', '4', 'leite.jpg', '4.99'),
	('Leite Integral UHT Mococa 1 Litro', '4', 'leite.jpg', '5.24'),
	('Leite Integral UHT Ninho Forti+ Vitaminado 1 L', '4', 'leite.jpg', '5.99'),
	('Biscoito Passatempo Recheado Chocolate 130 g', '5', 'bolacha.jpg', '3.49'),
	('Biscoito Recheado Trakinas Chocolate 126g', '5', 'bolacha.jpg', '4.69'),
	('Biscoito Chocolate Calipso 130 g', '5', 'bolacha.jpg', '10.29'),
	('Biscoito Salgado Club Social Original Embalagem Econômica 288g', '6', 'biscoito.jpg', '9,59'),
	('Biscoito Cream Cracker Amanteigado Vitarella 350g', '6', 'biscoito.jpg', '6.19'),
	('Biscoito Triunfo Cream Cracker 345g', '6', 'biscoito.jpg', '5.29'),
	('Açúcar Refinado Da Barra 1Kg', '7', 'acucar.jpg', '4.79'),
	('Açúcar Cristal Caravelas 1kg', '7', 'acucar.jpg', '3.98'),
	('Açúcar Cristal Pateko 1 Kg', '7', 'acucar.jpg', '4.09'),
	('Café A Vácuo Do Centro 500g', '8', 'cafe.jpg', '15.99'),
	('Café em Pó União 500g', '8', 'cafe.jpg', '19.69'),
	('Café Almofada Tradicional 3 Corações 500g', '8', 'cafe.jpg', '18.79');
    
    SELECT COUNT(*) AS quantidade_total FROM (
    SELECT * FROM produtos_brasil
    UNION ALL
    SELECT * FROM produtos_dia
    UNION ALL
    SELECT * FROM produtos_paguemenos
    UNION ALL
    SELECT * FROM produtos_oliveira
    UNION ALL
    SELECT * FROM produtos_sonda
    UNION ALL
    SELECT * FROM produtos_topazio
    UNION ALL
    SELECT * FROM produtos_atacadao
    UNION ALL
    SELECT * FROM produtos_caetano
    UNION ALL
    SELECT * FROM produtos_enxuto
) AS subquery;
SELECT COUNT(DISTINCT tabela) AS quantidade_mercados FROM (
    SELECT 'produtos_brasil' AS tabela FROM produtos_brasil
    UNION
    SELECT 'produtos_dia' AS tabela FROM produtos_dia
    UNION
    SELECT 'produtos_paguemenos' AS tabela FROM produtos_paguemenos
    UNION
    SELECT 'produtos_oliveira' AS tabela FROM produtos_oliveira
    UNION
    SELECT 'produtos_sonda' AS tabela FROM produtos_sonda
    UNION
    SELECT 'produtos_topazio' AS tabela FROM produtos_topazio
    UNION
    SELECT 'produtos_atacadao' AS tabela FROM produtos_atacadao
    UNION
    SELECT 'produtos_caetano' AS tabela FROM produtos_caetano
    UNION
    SELECT 'produtos_enxuto' AS tabela FROM produtos_enxuto
) AS subquery;