﻿namespace ComparAQUI
{
    partial class TelaInicial
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaInicial));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtBuscar = new System.Windows.Forms.TextBox();
            this.MinhaConta = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnColaborar = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnRaioBusca = new System.Windows.Forms.PictureBox();
            this.btnListaCompras = new System.Windows.Forms.PictureBox();
            this.lblListaCompras = new System.Windows.Forms.Label();
            this.lblRaioBusca = new System.Windows.Forms.Label();
            this.btnBuscar = new System.Windows.Forms.PictureBox();
            this.logoComparAQUI = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MinhaConta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnColaborar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRaioBusca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnListaCompras)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBuscar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoComparAQUI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(145)))), ((int)(((byte)(240)))));
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1270, 40);
            this.panel1.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(145)))), ((int)(((byte)(240)))));
            this.panel4.Location = new System.Drawing.Point(-2, 156);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1270, 40);
            this.panel4.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(72)))), ((int)(((byte)(200)))));
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.txtBuscar);
            this.panel2.Controls.Add(this.MinhaConta);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.btnColaborar);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.btnRaioBusca);
            this.panel2.Controls.Add(this.btnListaCompras);
            this.panel2.Controls.Add(this.lblListaCompras);
            this.panel2.Controls.Add(this.lblRaioBusca);
            this.panel2.Controls.Add(this.btnBuscar);
            this.panel2.Controls.Add(this.logoComparAQUI);
            this.panel2.Location = new System.Drawing.Point(1, 40);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1264, 116);
            this.panel2.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(216, 75);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(453, 258);
            this.panel3.TabIndex = 23;
            // 
            // txtBuscar
            // 
            this.txtBuscar.BackColor = System.Drawing.Color.White;
            this.txtBuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBuscar.Location = new System.Drawing.Point(216, 43);
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(453, 29);
            this.txtBuscar.TabIndex = 13;
            // 
            // MinhaConta
            // 
            this.MinhaConta.BackgroundImage = global::ComparAQUI.Properties.Resources.minha_conta;
            this.MinhaConta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.MinhaConta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MinhaConta.ErrorImage = null;
            this.MinhaConta.InitialImage = null;
            this.MinhaConta.Location = new System.Drawing.Point(1157, 32);
            this.MinhaConta.Name = "MinhaConta";
            this.MinhaConta.Size = new System.Drawing.Size(60, 40);
            this.MinhaConta.TabIndex = 22;
            this.MinhaConta.TabStop = false;
            this.MinhaConta.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1148, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 18);
            this.label1.TabIndex = 21;
            this.label1.Text = "Minha conta";
            // 
            // btnColaborar
            // 
            this.btnColaborar.BackgroundImage = global::ComparAQUI.Properties.Resources.colaborar;
            this.btnColaborar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnColaborar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColaborar.ErrorImage = null;
            this.btnColaborar.InitialImage = null;
            this.btnColaborar.Location = new System.Drawing.Point(1046, 32);
            this.btnColaborar.Name = "btnColaborar";
            this.btnColaborar.Size = new System.Drawing.Size(60, 40);
            this.btnColaborar.TabIndex = 20;
            this.btnColaborar.TabStop = false;
            this.btnColaborar.Click += new System.EventHandler(this.btnColaborar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(1044, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 18);
            this.label4.TabIndex = 19;
            this.label4.Text = "Colaborar";
            // 
            // btnRaioBusca
            // 
            this.btnRaioBusca.BackgroundImage = global::ComparAQUI.Properties.Resources.raio1;
            this.btnRaioBusca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnRaioBusca.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRaioBusca.ErrorImage = null;
            this.btnRaioBusca.InitialImage = null;
            this.btnRaioBusca.Location = new System.Drawing.Point(817, 32);
            this.btnRaioBusca.Name = "btnRaioBusca";
            this.btnRaioBusca.Size = new System.Drawing.Size(60, 40);
            this.btnRaioBusca.TabIndex = 18;
            this.btnRaioBusca.TabStop = false;
            this.btnRaioBusca.Click += new System.EventHandler(this.btnRaioBusca_Click);
            // 
            // btnListaCompras
            // 
            this.btnListaCompras.BackgroundImage = global::ComparAQUI.Properties.Resources.carrinho1;
            this.btnListaCompras.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnListaCompras.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnListaCompras.ErrorImage = null;
            this.btnListaCompras.InitialImage = null;
            this.btnListaCompras.Location = new System.Drawing.Point(934, 32);
            this.btnListaCompras.Name = "btnListaCompras";
            this.btnListaCompras.Size = new System.Drawing.Size(60, 40);
            this.btnListaCompras.TabIndex = 17;
            this.btnListaCompras.TabStop = false;
            // 
            // lblListaCompras
            // 
            this.lblListaCompras.AutoSize = true;
            this.lblListaCompras.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblListaCompras.ForeColor = System.Drawing.Color.White;
            this.lblListaCompras.Location = new System.Drawing.Point(911, 76);
            this.lblListaCompras.Name = "lblListaCompras";
            this.lblListaCompras.Size = new System.Drawing.Size(106, 18);
            this.lblListaCompras.TabIndex = 16;
            this.lblListaCompras.Text = "Lista de Compras";
            // 
            // lblRaioBusca
            // 
            this.lblRaioBusca.AutoSize = true;
            this.lblRaioBusca.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaioBusca.ForeColor = System.Drawing.Color.White;
            this.lblRaioBusca.Location = new System.Drawing.Point(803, 75);
            this.lblRaioBusca.Name = "lblRaioBusca";
            this.lblRaioBusca.Size = new System.Drawing.Size(88, 18);
            this.lblRaioBusca.TabIndex = 15;
            this.lblRaioBusca.Text = "Raio de Busca";
            // 
            // btnBuscar
            // 
            this.btnBuscar.BackgroundImage = global::ComparAQUI.Properties.Resources.botao_buscar;
            this.btnBuscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnBuscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscar.ErrorImage = null;
            this.btnBuscar.InitialImage = null;
            this.btnBuscar.Location = new System.Drawing.Point(675, 32);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(85, 51);
            this.btnBuscar.TabIndex = 9;
            this.btnBuscar.TabStop = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // logoComparAQUI
            // 
            this.logoComparAQUI.BackgroundImage = global::ComparAQUI.Properties.Resources.logo_menor;
            this.logoComparAQUI.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.logoComparAQUI.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logoComparAQUI.ErrorImage = null;
            this.logoComparAQUI.InitialImage = null;
            this.logoComparAQUI.Location = new System.Drawing.Point(67, 6);
            this.logoComparAQUI.Name = "logoComparAQUI";
            this.logoComparAQUI.Size = new System.Drawing.Size(104, 103);
            this.logoComparAQUI.TabIndex = 0;
            this.logoComparAQUI.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(220, 118);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(391, 105);
            this.dataGridView1.TabIndex = 0;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button9.BackgroundImage")));
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(986, 465);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(187, 187);
            this.button9.TabIndex = 8;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(691, 465);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(187, 187);
            this.button8.TabIndex = 7;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(390, 465);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(187, 187);
            this.button7.TabIndex = 6;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(89, 465);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(187, 187);
            this.button6.TabIndex = 5;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(986, 229);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(187, 187);
            this.button5.TabIndex = 4;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(691, 229);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(187, 187);
            this.button4.TabIndex = 3;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(389, 229);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(187, 187);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(89, 229);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(187, 187);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // TelaInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.ClientSize = new System.Drawing.Size(1203, 673);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1280, 718);
            this.MinimumSize = new System.Drawing.Size(1202, 698);
            this.Name = "TelaInicial";
            this.Text = "ComparAQUI";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MinhaConta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnColaborar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRaioBusca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnListaCompras)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBuscar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoComparAQUI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.PictureBox logoComparAQUI;
        private System.Windows.Forms.PictureBox btnBuscar;
        private System.Windows.Forms.PictureBox MinhaConta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox btnColaborar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox btnRaioBusca;
        private System.Windows.Forms.PictureBox btnListaCompras;
        private System.Windows.Forms.Label lblListaCompras;
        private System.Windows.Forms.Label lblRaioBusca;
        private System.Windows.Forms.TextBox txtBuscar;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel3;
    }
}

