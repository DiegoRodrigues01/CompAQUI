﻿using ComparAQUI;
using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace Cadastro
{
    public partial class TelaLogin : Form
    {
        private CadastroPessoa cadastro;

        public TelaLogin(CadastroPessoa cadastro)
        {
            InitializeComponent();
            this.cadastro = cadastro;
            txtSenha.UseSystemPasswordChar = true;
        }
        private void btnEntrar_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string senha = txtSenha.Text.Trim();

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(senha))
            {
                MessageBox.Show("Insira o email e a senha!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Verifica se o email e a senha estão na base de dados
                if (cadastro.ValidarLogin(email, senha))
                {
                    MessageBox.Show("Login realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Abrir a tela principal ou executar ações desejadas após o login
                    this.Close();
                    TelaColaborar colaborar = new TelaColaborar();
                    colaborar.Show();
                }
                else
                {
                    MessageBox.Show("Credenciais inválidas!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (MySqlException erro)
            {
                MessageBox.Show(erro.Message, "Erro de Banco de Dados", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } 
        }
        private void MinhaConta_Click(object sender, EventArgs e)
        {
            this.Close();
            CadastroPessoa cadastroPessoa = new CadastroPessoa();

            TelaCadastro cadastro = new TelaCadastro(cadastroPessoa);
            cadastro.Show();
        }
        private void CadastroPessoa_Click(object sender, EventArgs e)
        {
            this.Close();
            CadastroPessoa cadastroPessoa = new CadastroPessoa();

            TelaLogin login = new TelaLogin(cadastroPessoa);
            login.Show();
        }
        private void btnRaioBusca_Click(object sender, EventArgs e)
        {
            this.Close();
            TelaRaio telaRaio = new TelaRaio();
            telaRaio.Show();
        }
    }
}
