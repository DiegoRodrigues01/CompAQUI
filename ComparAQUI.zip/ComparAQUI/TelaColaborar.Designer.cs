﻿namespace ComparAQUI
{
    partial class TelaColaborar
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnBuscar = new System.Windows.Forms.PictureBox();
            this.btnRaioBusca = new System.Windows.Forms.PictureBox();
            this.btnListaCompras = new System.Windows.Forms.PictureBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.logoComparAQUI = new System.Windows.Forms.PictureBox();
            this.lblListaCompras = new System.Windows.Forms.Label();
            this.lblRaioBusca = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pnlCadastro = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBuscar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRaioBusca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnListaCompras)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoComparAQUI)).BeginInit();
            this.pnlCadastro.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(145)))), ((int)(((byte)(240)))));
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1693, 49);
            this.panel1.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(145)))), ((int)(((byte)(240)))));
            this.panel4.Location = new System.Drawing.Point(-3, 192);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1693, 49);
            this.panel4.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(72)))), ((int)(((byte)(200)))));
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.btnBuscar);
            this.panel2.Controls.Add(this.btnRaioBusca);
            this.panel2.Controls.Add(this.btnListaCompras);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.logoComparAQUI);
            this.panel2.Controls.Add(this.lblListaCompras);
            this.panel2.Controls.Add(this.lblRaioBusca);
            this.panel2.Location = new System.Drawing.Point(-3, 49);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1689, 143);
            this.panel2.TabIndex = 5;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::ComparAQUI.Properties.Resources.minha_conta;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.ErrorImage = null;
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(1533, 43);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(80, 49);
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1521, 97);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 23);
            this.label1.TabIndex = 13;
            this.label1.Text = "Minha conta";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::ComparAQUI.Properties.Resources.colaborar;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(1385, 43);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(80, 49);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(1383, 97);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 23);
            this.label4.TabIndex = 10;
            this.label4.Text = "Colaborar";
            // 
            // btnBuscar
            // 
            this.btnBuscar.BackgroundImage = global::ComparAQUI.Properties.Resources.botao_buscar;
            this.btnBuscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnBuscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscar.ErrorImage = null;
            this.btnBuscar.InitialImage = null;
            this.btnBuscar.Location = new System.Drawing.Point(900, 39);
            this.btnBuscar.Margin = new System.Windows.Forms.Padding(4);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(113, 63);
            this.btnBuscar.TabIndex = 9;
            this.btnBuscar.TabStop = false;
            // 
            // btnRaioBusca
            // 
            this.btnRaioBusca.BackgroundImage = global::ComparAQUI.Properties.Resources.raio1;
            this.btnRaioBusca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnRaioBusca.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRaioBusca.ErrorImage = null;
            this.btnRaioBusca.InitialImage = null;
            this.btnRaioBusca.Location = new System.Drawing.Point(1080, 43);
            this.btnRaioBusca.Margin = new System.Windows.Forms.Padding(4);
            this.btnRaioBusca.Name = "btnRaioBusca";
            this.btnRaioBusca.Size = new System.Drawing.Size(80, 49);
            this.btnRaioBusca.TabIndex = 8;
            this.btnRaioBusca.TabStop = false;
            // 
            // btnListaCompras
            // 
            this.btnListaCompras.BackgroundImage = global::ComparAQUI.Properties.Resources.carrinho1;
            this.btnListaCompras.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnListaCompras.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnListaCompras.ErrorImage = null;
            this.btnListaCompras.InitialImage = null;
            this.btnListaCompras.Location = new System.Drawing.Point(1236, 43);
            this.btnListaCompras.Margin = new System.Windows.Forms.Padding(4);
            this.btnListaCompras.Name = "btnListaCompras";
            this.btnListaCompras.Size = new System.Drawing.Size(80, 49);
            this.btnListaCompras.TabIndex = 7;
            this.btnListaCompras.TabStop = false;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(288, 57);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(603, 34);
            this.textBox2.TabIndex = 12;
            // 
            // logoComparAQUI
            // 
            this.logoComparAQUI.BackgroundImage = global::ComparAQUI.Properties.Resources.logo_menor;
            this.logoComparAQUI.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.logoComparAQUI.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logoComparAQUI.ErrorImage = null;
            this.logoComparAQUI.InitialImage = null;
            this.logoComparAQUI.Location = new System.Drawing.Point(89, 7);
            this.logoComparAQUI.Margin = new System.Windows.Forms.Padding(4);
            this.logoComparAQUI.Name = "logoComparAQUI";
            this.logoComparAQUI.Size = new System.Drawing.Size(139, 127);
            this.logoComparAQUI.TabIndex = 0;
            this.logoComparAQUI.TabStop = false;
            // 
            // lblListaCompras
            // 
            this.lblListaCompras.AutoSize = true;
            this.lblListaCompras.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblListaCompras.ForeColor = System.Drawing.Color.White;
            this.lblListaCompras.Location = new System.Drawing.Point(1205, 97);
            this.lblListaCompras.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblListaCompras.Name = "lblListaCompras";
            this.lblListaCompras.Size = new System.Drawing.Size(131, 23);
            this.lblListaCompras.TabIndex = 6;
            this.lblListaCompras.Text = "Lista de Compras";
            // 
            // lblRaioBusca
            // 
            this.lblRaioBusca.AutoSize = true;
            this.lblRaioBusca.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaioBusca.ForeColor = System.Drawing.Color.White;
            this.lblRaioBusca.Location = new System.Drawing.Point(1061, 96);
            this.lblRaioBusca.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRaioBusca.Name = "lblRaioBusca";
            this.lblRaioBusca.Size = new System.Drawing.Size(110, 23);
            this.lblRaioBusca.TabIndex = 4;
            this.lblRaioBusca.Text = "Raio de Busca";
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Mercado Brasil",
            "Dia- Dia",
            "Paguemenos",
            "Supermercado Oliveira",
            "Sonda",
            "Atacadão",
            "Supermercado Caetano",
            "Enxuto"});
            this.comboBox3.Location = new System.Drawing.Point(37, 79);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(352, 37);
            this.comboBox3.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.label3.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(35, 46);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(264, 30);
            this.label3.TabIndex = 15;
            this.label3.Text = "Selecione o supermercado:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.button1.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.button1.Location = new System.Drawing.Point(40, 479);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(353, 42);
            this.button1.TabIndex = 20;
            this.button1.Text = "Colaborar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.label6.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(35, 309);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(302, 30);
            this.label6.TabIndex = 22;
            this.label6.Text = "Digite o novo valor do produto:";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(37, 355);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(352, 36);
            this.textBox3.TabIndex = 23;
            // 
            // comboBox5
            // 
            this.comboBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "Arroz",
            "Feijão",
            "Macarrão",
            "Café",
            "Sal",
            "Açúcar",
            ",Café",
            "Leite"});
            this.comboBox5.Location = new System.Drawing.Point(37, 227);
            this.comboBox5.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(352, 37);
            this.comboBox5.TabIndex = 24;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.label7.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(32, 178);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(205, 30);
            this.label7.TabIndex = 25;
            this.label7.Text = "Selecione o produto:";
            // 
            // pnlCadastro
            // 
            this.pnlCadastro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.pnlCadastro.Controls.Add(this.label7);
            this.pnlCadastro.Controls.Add(this.button1);
            this.pnlCadastro.Controls.Add(this.comboBox5);
            this.pnlCadastro.Controls.Add(this.textBox3);
            this.pnlCadastro.Controls.Add(this.label6);
            this.pnlCadastro.Controls.Add(this.comboBox3);
            this.pnlCadastro.Controls.Add(this.label3);
            this.pnlCadastro.Location = new System.Drawing.Point(635, 249);
            this.pnlCadastro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlCadastro.Name = "pnlCadastro";
            this.pnlCadastro.Size = new System.Drawing.Size(421, 546);
            this.pnlCadastro.TabIndex = 31;
            // 
            // TelaColaborar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.ClientSize = new System.Drawing.Size(1683, 826);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlCadastro);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1701, 873);
            this.MinimumSize = new System.Drawing.Size(1437, 856);
            this.Name = "TelaColaborar";
            this.Text = "ComparAQUI";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBuscar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRaioBusca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnListaCompras)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoComparAQUI)).EndInit();
            this.pnlCadastro.ResumeLayout(false);
            this.pnlCadastro.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblRaioBusca;
        private System.Windows.Forms.Label lblListaCompras;
        private System.Windows.Forms.PictureBox logoComparAQUI;
        private System.Windows.Forms.PictureBox btnListaCompras;
        private System.Windows.Forms.PictureBox btnRaioBusca;
        private System.Windows.Forms.PictureBox btnBuscar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlCadastro;
    }
}

