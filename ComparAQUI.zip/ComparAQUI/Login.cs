﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastro
{
    public class Login
    {
        private string nome;
        private string cpf;
        private string email;
        private string senha;
        public Login(string nome, string cpf, string email, string senha)
        {
            this.nome = nome;
            this.cpf = cpf;
            this.email = email;
            this.senha = senha;
        }
        public string getNome() { return nome; }
        public string getCPF() { return cpf; }
        public string getEmail() { return email; }
        public string getSenha() { return senha; }
    }
}
