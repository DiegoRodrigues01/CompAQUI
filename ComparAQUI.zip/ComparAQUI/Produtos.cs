﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComparAQUI
{
    internal class Produtos
    {
        private string nomeProduto;
        private string valorProduto;
        private string categoriaProdutos;    
        public Produtos(string nomeProduto, string ValorProduto, string categoriaProdutos)
        {
            this.nomeProduto = nomeProduto;
            this.valorProduto = ValorProduto;
            this.categoriaProdutos= categoriaProdutos;
        }
        public string getNome() { return nomeProduto; }
        public string getProduto() { return valorProduto; }
        public string getCategorial() { return categoriaProdutos; }
    }
}
