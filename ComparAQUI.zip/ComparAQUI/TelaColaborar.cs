﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ComparAQUI
{
    public partial class TelaColaborar : Form
    {
        // Configuração da conexão com o banco de dados
        string connectionString = @"server=localhost;
                              port=3306;
                              uid=root;
                              pwd=1234;database=comparaqui;
                              ConnectionTimeout=1";
        public TelaColaborar()
        {
            InitializeComponent();
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            string mercado = comboBox3.SelectedItem?.ToString();
            string produto = comboBox5.SelectedItem?.ToString();

            // Verificar se os campos foram preenchidos
            if (string.IsNullOrEmpty(mercado) || string.IsNullOrEmpty(produto))
            {
                MessageBox.Show("Selecione um mercado e um produto!");
                return;
            }
            // Obter o novo preço digitado na TextBox 3
            decimal novoPreco;
            if (decimal.TryParse(textBox3.Text, out novoPreco))
            {
                try
                {
                    // Atualizar o banco de dados com o novo preço
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "UPDATE TabelaProdutos SET Preco = @NovoPreco WHERE Mercado = @Mercado AND Produto = @Produto";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@NovoPreco", novoPreco);
                        command.Parameters.AddWithValue("@Mercado", mercado);
                        command.Parameters.AddWithValue("@Produto", produto);
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Preço atualizado com sucesso!");
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível encontrar o mercado e/ou produto especificados!");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao atualizar o preço: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Digite um valor válido para o preço!");
            }
        }
    }
}