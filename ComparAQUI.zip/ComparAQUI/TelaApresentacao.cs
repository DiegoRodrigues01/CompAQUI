﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComparAQUI
{
    public partial class TelaApresentacao : Form
    {
        public TelaApresentacao()
        {
            InitializeComponent();
        }
        private void btnAvancar_Click(object sender, EventArgs e)
        {
            TelaRaio tela_raio  = new TelaRaio();
            tela_raio.Show();
        }
    }
}