﻿namespace ComparAQUI
{
    partial class TelaRaio
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelRaio = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rd_btn3 = new System.Windows.Forms.RadioButton();
            this.lbl3Km = new System.Windows.Forms.Label();
            this.rd_btn2 = new System.Windows.Forms.RadioButton();
            this.lbl10Km = new System.Windows.Forms.Label();
            this.rd_btn1 = new System.Windows.Forms.RadioButton();
            this.lbl5Km = new System.Windows.Forms.Label();
            this.btnConfirmar = new System.Windows.Forms.Button();
            this.lblRaio = new System.Windows.Forms.Label();
            this.btnRetornar = new System.Windows.Forms.Button();
            this.panelRaio.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(145)))), ((int)(((byte)(240)))));
            this.panel3.Location = new System.Drawing.Point(-3, 789);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1693, 49);
            this.panel3.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(145)))), ((int)(((byte)(240)))));
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1693, 49);
            this.panel1.TabIndex = 2;
            // 
            // panelRaio
            // 
            this.panelRaio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.panelRaio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelRaio.Controls.Add(this.panel2);
            this.panelRaio.Controls.Add(this.btnConfirmar);
            this.panelRaio.Location = new System.Drawing.Point(643, 273);
            this.panelRaio.Margin = new System.Windows.Forms.Padding(4);
            this.panelRaio.Name = "panelRaio";
            this.panelRaio.Size = new System.Drawing.Size(406, 322);
            this.panelRaio.TabIndex = 7;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gainsboro;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.rd_btn3);
            this.panel2.Controls.Add(this.lbl3Km);
            this.panel2.Controls.Add(this.rd_btn2);
            this.panel2.Controls.Add(this.lbl10Km);
            this.panel2.Controls.Add(this.rd_btn1);
            this.panel2.Controls.Add(this.lbl5Km);
            this.panel2.Location = new System.Drawing.Point(72, 44);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(258, 179);
            this.panel2.TabIndex = 8;
            // 
            // rd_btn3
            // 
            this.rd_btn3.AutoSize = true;
            this.rd_btn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rd_btn3.Location = new System.Drawing.Point(107, 133);
            this.rd_btn3.Margin = new System.Windows.Forms.Padding(4);
            this.rd_btn3.Name = "rd_btn3";
            this.rd_btn3.Size = new System.Drawing.Size(17, 16);
            this.rd_btn3.TabIndex = 0;
            this.rd_btn3.TabStop = true;
            this.rd_btn3.UseVisualStyleBackColor = true;
            // 
            // lbl3Km
            // 
            this.lbl3Km.AutoSize = true;
            this.lbl3Km.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3Km.Location = new System.Drawing.Point(5, 12);
            this.lbl3Km.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl3Km.Name = "lbl3Km";
            this.lbl3Km.Size = new System.Drawing.Size(52, 28);
            this.lbl3Km.TabIndex = 1;
            this.lbl3Km.Text = "3 KM";
            // 
            // rd_btn2
            // 
            this.rd_btn2.AutoSize = true;
            this.rd_btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rd_btn2.Location = new System.Drawing.Point(107, 76);
            this.rd_btn2.Margin = new System.Windows.Forms.Padding(4);
            this.rd_btn2.Name = "rd_btn2";
            this.rd_btn2.Size = new System.Drawing.Size(17, 16);
            this.rd_btn2.TabIndex = 0;
            this.rd_btn2.TabStop = true;
            this.rd_btn2.UseVisualStyleBackColor = true;
            // 
            // lbl10Km
            // 
            this.lbl10Km.AutoSize = true;
            this.lbl10Km.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl10Km.Location = new System.Drawing.Point(4, 124);
            this.lbl10Km.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl10Km.Name = "lbl10Km";
            this.lbl10Km.Size = new System.Drawing.Size(62, 28);
            this.lbl10Km.TabIndex = 2;
            this.lbl10Km.Text = "10 KM";
            // 
            // rd_btn1
            // 
            this.rd_btn1.AutoSize = true;
            this.rd_btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rd_btn1.Location = new System.Drawing.Point(107, 21);
            this.rd_btn1.Margin = new System.Windows.Forms.Padding(4);
            this.rd_btn1.Name = "rd_btn1";
            this.rd_btn1.Size = new System.Drawing.Size(17, 16);
            this.rd_btn1.TabIndex = 0;
            this.rd_btn1.TabStop = true;
            this.rd_btn1.UseVisualStyleBackColor = true;
            //this.rd_btn1.CheckedChanged += new System.EventHandler(this.rd_btn1_CheckedChanged);
            // 
            // lbl5Km
            // 
            this.lbl5Km.AutoSize = true;
            this.lbl5Km.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5Km.Location = new System.Drawing.Point(4, 67);
            this.lbl5Km.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl5Km.Name = "lbl5Km";
            this.lbl5Km.Size = new System.Drawing.Size(53, 28);
            this.lbl5Km.TabIndex = 2;
            this.lbl5Km.Text = "5 KM";
            // 
            // btnConfirmar
            // 
            this.btnConfirmar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.btnConfirmar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirmar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmar.Location = new System.Drawing.Point(119, 245);
            this.btnConfirmar.Margin = new System.Windows.Forms.Padding(4);
            this.btnConfirmar.Name = "btnConfirmar";
            this.btnConfirmar.Size = new System.Drawing.Size(172, 59);
            this.btnConfirmar.TabIndex = 5;
            this.btnConfirmar.Text = "Confirmar";
            this.btnConfirmar.UseVisualStyleBackColor = false;
            this.btnConfirmar.Click += new System.EventHandler(this.btnConfirmar_Click_1);
            // 
            // lblRaio
            // 
            this.lblRaio.AutoSize = true;
            this.lblRaio.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.lblRaio.Location = new System.Drawing.Point(612, 138);
            this.lblRaio.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRaio.Name = "lblRaio";
            this.lblRaio.Size = new System.Drawing.Size(465, 112);
            this.lblRaio.TabIndex = 8;
            this.lblRaio.Text = "Escolha o raio de busca e a partir de sua localização, \r\nfaremos a pesquisa de qu" +
    "al mercado oferece os \r\nmelhores preços segundo sua lista de compras:\r\n\r\n";
            // 
            // btnRetornar
            // 
            this.btnRetornar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.btnRetornar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRetornar.Font = new System.Drawing.Font("Fira Sans Extra Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRetornar.ForeColor = System.Drawing.Color.White;
            this.btnRetornar.Location = new System.Drawing.Point(23, 687);
            this.btnRetornar.Margin = new System.Windows.Forms.Padding(4);
            this.btnRetornar.Name = "btnRetornar";
            this.btnRetornar.Size = new System.Drawing.Size(196, 71);
            this.btnRetornar.TabIndex = 9;
            this.btnRetornar.Text = "Retornar";
            this.btnRetornar.UseVisualStyleBackColor = false;
            this.btnRetornar.Click += new System.EventHandler(this.btnRetornar_Click);
            // 
            // TelaRaio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(116)))));
            this.ClientSize = new System.Drawing.Size(1683, 828);
            this.Controls.Add(this.panelRaio);
            this.Controls.Add(this.lblRaio);
            this.Controls.Add(this.btnRetornar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1701, 875);
            this.MinimumSize = new System.Drawing.Size(1701, 875);
            this.Name = "TelaRaio";
            this.Text = "ComparAQUI";
            this.panelRaio.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelRaio;
        private System.Windows.Forms.Button btnConfirmar;
        private System.Windows.Forms.Label lbl10Km;
        private System.Windows.Forms.RadioButton rd_btn3;
        private System.Windows.Forms.Label lbl5Km;
        private System.Windows.Forms.RadioButton rd_btn2;
        private System.Windows.Forms.Label lblRaio;
        private System.Windows.Forms.Button btnRetornar;
        private System.Windows.Forms.RadioButton rd_btn1;
        private System.Windows.Forms.Label lbl3Km;
        private System.Windows.Forms.Panel panel2;
    }
}

