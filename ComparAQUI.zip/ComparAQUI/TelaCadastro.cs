﻿using ComparAQUI;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cadastro
{
    public partial class TelaCadastro : Form
    {
        private CadastroPessoa cadastro;
        public TelaCadastro(CadastroPessoa cadastro)
        {
            InitializeComponent();
            this.cadastro = cadastro;
        }
        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            //recupera o texto do componente textbox e remove os espaços em branco do começo e fim
            string nome = txtNome.Text.Trim();
            if (nome == "") {
                MessageBox.Show("Insira um valor para o campo \"Nome\"");
                return;
            }
            //recupera o texto do componente textbox e remove os espaços em branco do começo e fim
            string cpf = txtCPF.Text.Trim();
            if (cpf == "")
            {
                MessageBox.Show("Insira um valor para o campo \"CPF\"");
                return;
            }
            //pega e valida os dados do textbox
            string email = txtEmail.Text.Trim();
            if (email == "")
            {
                MessageBox.Show("Insira um valor para o campo \"Email\"");
                return;
            }
            if (!email.Contains("@"))
            {
                MessageBox.Show("O campo \"Email\" não contém um endereço de email válido");
                return;
            }
            //pega e valida os dados do textbox
            string senha = txtSenha.Text.Trim();
            if (senha == "")
            {
                MessageBox.Show("Insira um valor para o campo \"Nome\"");
                return;
            }
            //pega e valida os dados do textbox
            try
            {
                //cria um objeto funcionário com os dados dos textbox
                Login login = new Login(nome, cpf, email, senha);

                //cadastra o funcionario no banco
                cadastro.Pessoa(login);

                //limpa os textbox com os dados do funcionario
                clearTextBox();

                //informa o usuário que o funcionario foi cadastrado no banco
                MessageBox.Show("Dados Salvos!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //trata os erros relacionados ao banco
            catch (MySqlException erro)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine(erro.GetType().ToString());
                sb.AppendLine(erro.Message);
                sb.Append(erro.SqlState);
                sb.AppendLine("\n");
                sb.AppendLine(erro.StackTrace);
                MessageBox.Show(sb.ToString(), "ERRO BANCO!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //tratamento dos demais erros que possam ocorrer
            catch (Exception erro)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine(erro.GetType().ToString());
                sb.AppendLine(erro.Message);
                sb.AppendLine("\n");
                sb.AppendLine(erro.StackTrace);
                MessageBox.Show(sb.ToString(), "ERRO Desconhecido!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //limpa os textbox de dados
        private void clearTextBox()
        {
            txtNome.Clear();
            txtCPF.Clear();
            txtEmail.Clear();
            txtSenha.Clear();
        }
        private void btnRaioBusca_Click(object sender, EventArgs e)
        {
            this.Close();
            TelaRaio telaRaio = new TelaRaio();
            telaRaio.Show();
        }
        private void btnColaborar_Click(object sender, EventArgs e)
        {
            this.Close();
            CadastroPessoa cadastroPessoa = new CadastroPessoa();

            TelaLogin login = new TelaLogin(cadastroPessoa);
            login.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}

