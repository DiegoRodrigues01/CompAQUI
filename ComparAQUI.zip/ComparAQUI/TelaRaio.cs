﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace ComparAQUI
{
    public partial class TelaRaio : Form
    {
        public TelaRaio()
        {
            InitializeComponent();
        }
        private void btnRetornar_Click(object sender, EventArgs e)
        {
            TelaApresentacao telaapresentacao = new TelaApresentacao();
            telaapresentacao.Show();
            this.Close();
        }
        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            if (rd_btn1.Checked)
            {
                TelaInicial telainical = new TelaInicial();
                telainical.Show();
                this.Close();
            }
           else if (rd_btn2.Checked)
            {
                TelaInicial telainical = new TelaInicial();
                telainical.Show();
                this.Close();
            }
            else if(rd_btn3.Checked)
            {
                TelaInicial telainical = new TelaInicial();
                telainical.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show(" Por favor, escolha um raio de busca para prosseguir!");
                this.Close();
            }
        }
        private void btnConfirmar_Click_1(object sender, EventArgs e)
        {
            if(rd_btn1.Checked)
            {
                TelaInicial telainicial = new TelaInicial();
                telainicial.Show();
                this.Close();
            }
            else  if(rd_btn2.Checked)
            {
                TelaInicial telainicial = new TelaInicial();
                telainicial.Show();
                this.Close();
            }
            else if(rd_btn3.Checked)
            {
                TelaInicial telainicial = new TelaInicial();
                telainicial.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Por gentileza defina um raio de localização");
            }
        }
    }
}
